# Storylining

Storylining owns the decision, proof, evidence definitions and page selection. Design begins only when those are coherent.

## Define the communication job

Above the dot-dash, record the audience, actual choice or learning objective, baseline and alternatives, horizon, ranked criteria, fixed constraints, evidence gaps and the condition that changes the answer. Distinguish user preferences from assumptions. Resolve the decision stage: diagnosis, option selection, recommendation, authorization or explanation. A sourced annual comparison cannot answer a three-year commitment merely by being labelled correctly.

For authorization, retain one approval unit: workflow, population, exposure/configuration, resources and permission requested. Preparation, offline testing, live exposure and expansion are different commitments. Carry the same unit into the summary, protocol and close. Include cancellation, option and contingent liabilities in the authorized exposure, even when cash is released later. A request for preparatory spending needs its own supported purpose, downside and stop condition; a conditional main programme does not automatically justify its first tranche. Ask only for missing information that would change the argument; existing authorization persists.

## Find the data before the dot-dash

A dot-dash written from what the author already knows produces pages of two numbers each: one company against another on a count. The rich page - a trend with its growth rate, the whole peer set ranked, a share shifting, a network on a map - needs a dataset, and the datasets have to be found before the titles are written, because they decide which titles can be proved.

For a subject with public records, search for and download the data first:

- **Series over time** for the measures the question turns on - revenue, profit, volume, capacity, users, fleet, share - five or more periods, from annual reports, investor presentations, regulators, statistics offices and industry bodies. Country-level series (passengers, GDP, population, tourism, energy) come in one call: `node runtime/fetch-series.mjs worldbank IS.AIR.PSGR SAU,ARE,QAT --from 2010` or `... owid <grapher-slug> "Saudi Arabia,Qatar"` writes the CSV, its source and retrieval date, each series' CAGR and a chart block ready for the exhibit.
- **The whole peer set** on the same measures and the same basis, not the subject against one rival.
- **Composition and share**: segments, regions, product lines, and how they have shifted.
- **Geography**: locations, networks and routes, with coordinates.
- **Pipeline and commitments**: orders, plans, announcements, each with its status (announced, firm, delivered).
- **Ratios that remove size**: per unit, per head, per route, per asset.

Save what is downloaded under the task's `sources/` with the URL and the retrieval date, and build each measure's record from it (below). Where a series is not published, say so and use the nearest defensible one; do not fall back to a two-number chart because the search was short. Declare the compared organisations as `players` on the deck - name, and the logo to be sourced - so the deck introduces them before it compares them ([Design](design.md#make-every-exhibit-earn-its-page)).

Then [extract the insights](#extract-the-insights-before-the-titles) from the data before writing a title. Before writing titles, list the deck's candidate exhibits against these forms. A 50-page deck on a competitive question normally carries several trends with their rates, a ranked peer comparison, a share or mix, a players page with logos, a map where the subject has geography, and scorecard tables that judge; if the list is mostly single-period comparisons of two entities, the research is not finished.

## Prove the governing answer

Build a hypothesis tree for a decision, or a concept/dependency map for explanation. Use stable node IDs. For each terminal branch retain the provisional answer, confirming/disconfirming evidence, consequence, evidence status, dependency and disposition (body, appendix, unresolved or parked). Siblings divide the same parent question. Stop expanding when additional detail cannot change the answer or understanding.

Name the actual competing route and the constraint it can or cannot change. “Test whether ownership helps” is an open research question, not evidence of an ownership mechanism. State a common outcome and the observation that would reject the proposed advantage. If the difference is unknown, retain that gap and its consequence; do not replace it with hypothetical precision.

Write the exact title of every page. Under each title state the evidence that settles it, what it builds on, what is new and the audience consequence. A comparative title needs comparable proof on both sides. A selected example establishes an instance; a median establishes location, not consistency; a correlation or arithmetic bridge does not establish causality. A causal account requires evidence of the mechanism, and a decomposition states its baseline/allocation order.

Place a governing prerequisite before the first substantive option comparison that relies on it, or show its decisive proof locally in that comparison. An opening answer can lead; later analysis should not repeatedly invoke an upstream capacity, entitlement or accounting limit before explaining it. Keep the constraint beside its first consequential use rather than isolating it in a later thematic section that forces backward reconstruction.

Before layout, compare every page with its closest sibling. Draft the merged alternative. Retain separate pages only when joining them materially harms a necessary comparison, explanation or lookup. Different titles, extra caveats and another arithmetic step are insufficient. A ratio, its distance from a threshold and the same distance restated in currency normally belong in one local comparison. A newly derived number is not a new evidence question merely because it inverts or rearranges an existing equation; retain a separate page only when it exposes another consequential relationship that the merged proof cannot carry. Use existing `settles`, `adds` and plan `why` fields to record the decision; no extra checklist is needed. Consolidate preview scorecards and repeated endings. Put the decisive countercases before the final authorization; join initial exposure, halfway cancellation and normal-completion states to that authorization when they reuse the same work and liability amounts. Audit detail earns its appendix role but is not credited as another persuasive premise. For example, merge a trigger recap into the actual decision; retain a separate appendix register only when readers need exact condition, governing input/equation, boundary and return action in one lookup. Moving the same summary to the appendix does not create that function.

Give secondary obstacles proportionate space. If an option already fails an essential prerequisite, attach a further cost or execution obstacle to that option unless it could reopen the choice or the brief requires its detailed examination. For example, a plant with no additional water entitlement need not receive another full page about its unavailable shutdown window. Preserve the timing gap and unproven remedies beside the plant constraint. By contrast, peak delivery and prolonged supply volume can earn separate proofs when each independently changes the governing case.

Challenge adjacent schedules that repeat the same activities under resource and dependency headings. A common time axis can join upstream permissions/procurement, revised activities, integration and a compact original-versus-revised resource comparison. Preserve every governing duration, dependency and separate resource; combine only when those proofs remain readable. Another schedule title alone does not earn repeated task rows.

For repeated permission or readiness summaries, compare the exact record keys with the option evidence and preparation ledger. Preserve each condition once where it changes an option, and provide consolidated lookup only when it adds the record, boundary and action readers need. A general permissions page does not earn a separate role by repeating those conditions without a new conclusion. Similarly, source lineage, required replacement evidence and reproduction instructions can share a keyed audit record; different headings do not justify repeating the same evidence-state warning. When deletion takes an evaluation below its page minimum, return to evidence breadth: add a genuinely unanswered question supported by the sources, not another recap or a split made to recover the count.

Long decks are legitimate: a diligence pack or a board pre-read can need 60 pages or more. For fixed length, budget cover, summary, sections and appendix first; select evidence breadth that supports the total - more analyses and a wider peer set, never repetition. Reject a narrow evaluation topic before authoring if it requires padding. Do not invent another case whenever a thin page is found. Alternative decks first differ in question, sequence or evidence relationship, not palette.

## Work in parallel with subagents

Research and analysis are the slow part of a deck and they split cleanly, so when the harness can spawn subagents (an agent or task tool), fan them out rather than working through the list alone. The lead agent keeps the question, the answer, the players and the title spine; subagents do bounded work and return files.

| Stage | Fan out by | Each subagent returns |
| --- | --- | --- |
| Find the data | Workstream: the subject's own series; each player or group of players; the market and demand; geography and networks; pipeline and commitments; the counter-case | Downloaded files under `sources/<workstream>/`, each with its URL and retrieval date, and a note of what it could not find |
| Extract the insights | The same workstreams, each working its own datasets | `insights-<workstream>.json` in the insight-log format, every finding with its calculation and sources |
| Draft the copy | Section, once the title spine is fixed | The section's pages in the content record's format, drawn only from the merged insight log |
| Critique | A fresh subagent every pass, never reused; one per section plus a spine critic for a long storyline | `storyline-review.json` ([stress-test](#stress-test-the-storyline)) |

Keep research proportionate. Use at most four workstreams, not one per player; give each a budget of about fifteen searches and a clear list of the decisive series to find; tell it to stop when those are found and to record what it could not find rather than keep searching. A second, targeted pass follows only when the storyline critique names a missing analysis that would change the answer.

Brief each subagent completely - it has none of your context: the question and the deck's answer so far, exactly what to find or work, the file formats and folders to write to, the date the evidence is current to, and what to do when something cannot be found (record it; never invent it). Run the workstreams at the same time. When they return, the lead merges the insight fragments into `<id>.insights.json`, removes duplicates, grades them across the deck, and writes the titles; only the lead edits the title spine. A harness with no subagents does the same stages in sequence.

## Extract the insights before the titles

Data is not yet a finding. Before a title is written, work the downloaded data the way an analyst would, and record what it says in `<id>.insights.json`:

```json
{ "schema": "professional-slides.insights/v1",
  "insights": [
    { "id": "i-launch-ramp",
      "finding": "Riyadh Air opened 14 destinations in its first 16 weeks, faster than Etihad's first year",
      "shape": "series",
      "breadth": { "periods": 16, "series": 5 },
      "calculation": "destinations by month since first scheduled flight, per carrier; Etihad from its 2003-06 launch records",
      "sources": ["sources/riyadh-air-routes-2026-09.csv", "sources/etihad-destinations-2003-2006.csv"],
      "soWhat": "the ramp, not the size, is the evidence for 'up and coming'",
      "strength": "strong",
      "exhibit": "trend: destinations by month since launch, five carriers, Riyadh Air highlighted" } ] }
```

Work through each dataset with the questions that turn numbers into findings:

- **Rate:** how fast is it growing, over what span? What CAGR would the target need, against the rate achieved?
- **Rank:** where does the subject sit in the whole set, and who is nearest?
- **Share and mix:** what share does it take, and how has the share moved?
- **Ratio:** what does it look like with size removed (per unit, per head, per route, per asset)?
- **Gap:** how far is it from the benchmark, the target, or the leader, and is the gap closing?
- **Break:** where does the series change direction, and what explains it?
- **Counter:** what in the data argues against the answer?

Keep the insights that are specific, surprising or decisive; a finding the reader could have guessed is not an insight. Grade each `strong`, `supporting` or `context`. Then write the titles from the insights - every analytical page carries at least one, the executive summary is built from the strongest, and the governing answer is the conclusion they add up to. An insight with no page is either cut or missing a page; a page with no insight is either cut or missing its analysis. The storyline critique reads the insight log beside the pages.

## Stress-test the storyline

Before anything is drawn, the storyline goes through a mock problem-solving session with a reader who did not write it. `node runtime/storyline.mjs <id>.deck.json out/` writes a packet - the question, the answer, the players, the data found, the insight log, and every page's title, what its exhibit shows (with two-number charts marked), what its commentary says and the insights it rests on, each with its calculation and sources - and a prompt for a senior, adversarial reader. The critique has to be complete the first time, because later passes only verify it.

**Pass one is exhaustive.** The critic returns (the first-pass schema in `runtime/storyline.mjs`):

- `pages`: one entry for **every** content page - its `verdict` (`ok`, `minor`, `major`, `blocker`, the worst open item naming it) and a note for each page check: `claim` (a finding with an implication, not a count or a fact), `shape` (the evidence has the shape the claim needs - the trend with its rate, the whole ranked peer set, the share, the ratio, the gap, the map, the judging table; members compared on the same measures), `sourcing` (`supported`, `partly`, `unsupported` or `n/a`, with the insight ids it rests on), `restatement` (it moves on from the page before) and `consequence` (it says what follows for the decision);
- `spine`: the titles read alone - do they tell the story;
- `answer`: the governing answer as it should read, if it restates the question or is too safe to be wrong;
- `pillars`: each pillar with its pages, a verdict, its overlaps and gaps (MECE), its strongest counter-argument, the condition that would reverse it, and whether the storyline answers it;
- `numbers` (the same figure, unit, base and period on every page, totals that reconcile), `sectionFlow`, and `execSummary` (the summary against the body and the close);
- `missingAnalyses` ({ `analysis`, `why`, `data` }), `cutOrMerge` (the pages, and what the freed pages should carry), `findings` and `topFixes`, every item with an id and a severity;
- `completeness`: for each check, `findings`, or `clean` with what was checked and why nothing was found.

Validation refuses a critique that misses a page, lists pages by example ("e.g.", "such as", "etc.") or names in its text a page its list leaves out, marks a page unsupported without a major sourcing finding, or says `ready` while a major or blocker item is open. For a spine of more than 30 content pages the packet also splits the page checks into section prompts (`storyline-review/sections/`, one per section, a long section cut into parts of at most 16 pages) and a spine prompt: give each to its own fresh critic at the same time, save the answers in `storyline-review/parts/`, and `node runtime/storyline.mjs merge <id>.deck.json out/` joins them, refusing a page no section read or two sections both read - the deck review splits and merges the same way.

Run the loop - the critic judges from the packet alone, with no web research:

1. **Spawn a fresh subagent** as the critic - the harness's agent or task tool, or `--run codex` / `--run claude` when that CLI is installed. Give it only the path to `prompt.md` and ask it to return the JSON. It gets none of the author's reasoning, notes or earlier reviews: a critic that knows what the author meant forgives what the page fails to show.
2. **Save** its JSON as `out/storyline-review.json` and run `storyline.mjs` again: it validates the critique against the packet it answered and records it in `out/storyline-history/`. Only that answer counts: a critique that answers no packet `storyline.mjs` wrote is refused, however well formed, and once a pass is recorded its verdict is read from the record, not from the file.
3. **Revise at the root.** A missing analysis means more research, not a new sentence: go back to [the data](#find-the-data-before-the-dot-dash), download the series, and rebuild the pages. A two-number chart becomes the whole peer set or the trend; a plain or word-filled table becomes a scorecard with numbers and a treatment in the cells; an obvious page is cut or merged.
4. **Verify.** Run `storyline.mjs` again. With the spine changed it writes a verification packet: the critic gives every open item a status (`fixed`, `partly fixed`, `not fixed`, `regressed`) with its evidence, re-reads the changed pages, and may add an item only if it is major or blocker and additive - on a changed page, introduced by the revision, or a blocker the first pass demonstrably missed, with the reason it was not visible. A new minor point, or a point on an unchanged page, is refused, so the loop converges.
5. **Stop at `ready`, or at three passes.** `storyline.mjs` prints `ready` when the latest pass says ready, no major or blocker item from any pass is open, and it is bound to the current spine. A storyline still sent back after the third pass goes to the user with its open items; another pass runs only when they ask (`--max-passes`).

The bar the critic holds is a deck that feels important: every page carries evidence a reader could not assemble in five minutes, charts compare the whole set or a trend with its rate rather than two categories, and tables are dense with real numbers and judge in their cells.

The review is bound to the story's structure (page ids, titles, exhibits and what they plot): rewording a sentence keeps it, changing what a page argues or shows does not. **This gate comes before the copy and before any deck review:** `reviewer.mjs` will not write a deck-review packet and delivery refuses a deck (`STORYLINE_UNREVIEWED`) until `storyline-review.json` is `ready` for the current spine; a spine edited after the critique names its changed pages and asks for the critique to be run again first. Set `targetPages` on the deck when the user asked for a length, so the critic merges duplicates without cutting below it. Do not tell the reviewer the verdict you want.

Before the gate, a full `author-deck.mjs` compile (not `--draft`) and `build-deck.mjs` warn and carry on: the draft can be built and checked, but its copy is written against a spine the critique has not passed. Author-deck reads the gate in `out/` beside the pages file, or `--out <dir>`.

## Reconcile evidence before design

Verify factual premises and dated source status: rumour, announcement, agreement, approval and completion are distinct. Separate transaction consideration, contingent payments and retention costs; check superseded policies/rates. Track whether research is resolved, uncertain, unavailable after lookup, not yet performed or requires user input. Do not describe unperformed research as unavailable.

Keep one record for each reused measure or parameter: exact definition, member observations/ranges, exclusions, population, unit, period/snapshot, evidence state, inputs, formula and rounding. Sum members before drafting totals. Derive means, shares, distributions and durations from those records, retaining unrounded values and a stated quantile method. An arc, complete work, author run and series are different counted sets; a grouped cell may contain several members.

Parameter identity travels with values into labels, notes and summaries. Distinguish adoption from realization, transaction share from effort share, requests from people, capacity from schedulable release, and economic value from cash. Cost and benefit denominators can differ. Changing a parameter or cohort reopens every consumer: title, chart, note, source map, summary and close. Use existing source IDs and model records to locate consumers; do not retype derived numbers from memory.

Match alternatives on the same horizon and feasible commitment. Initial trial and optional continuation are distinct on both sides. An ordered route, independent choices and a sum of optional choices are not equivalent packages. Separate economic opportunity from avoided expenditure, with timing and accountable owner. Training can consume internal hours without adding payroll. Solve switching thresholds on the decision horizon, including one-time costs.

After individual sensitivities, join constraints that govern the same outcome into one feasible case or envelope. For example, released hours must also be schedulable, contractually cancellable and financially sufficient before they become cash savings. Keep the base, sensitivity, counterexample and revised governing case distinct. A correct series of isolated calculations can leave the central decision unproved. When an optimization has multiple equally good solutions, distinguish the identified total from a solver-selected local allocation. State any priority objective or prove a local minimum/range before calling an allocation unavoidable. Trace this distinction through every district, cohort or resource consumer, not only the example that exposed it. A downstream capacity increase cannot create an upstream input, permission or entitlement. Trace the limiting path and show which constraint each intervention actually changes; do not silently relax another constraint in an alternative. Derive operating triggers from the same feasibility equations and inputs as the recommendation, including required buffers and equality boundaries. A threshold copied into a protocol is another model consumer, not independent prose.

Match uncertainty to the sampling unit and selection method. Repeated observations are not independent cases; challenge sets do not establish population failure rates. When missing outcomes could reverse a decision, show bounds or a relevant sensitivity. An illustrative point estimate does not replace a protocol's uncertainty-based acceptance test.

Synthetic records have a defined role: mechanism demonstration, inference counterexample, proposed record or decision rehearsal. They cannot establish empirical demand, causal uplift or completed readiness. Store designed capacities, prices, thresholds and worked results in the cited fixture too; authoring-only numbers do not acquire provenance by citing a different file. Name which real evidence would replace them. [Production](tools/production.md#portable-evidence-and-release) owns isolated reproduction.

Test timing as well as totals when it can change the decision. An eventually funded programme can still breach a cash floor before receipts arrive. A timing stress keeps the unchanged spending and funding assumptions explicit, separates unrestricted liquidity from already committed programme cash, and reports peak required support as an unfunded requirement unless a facility is evidenced. Unmodelled fees, interest and covenant effects do not become compliant by omission.

Match interim resources to their actual availability period. Join repeated year-keyed spending, service gaps and temporary-measure ceilings when that makes the feasible case easier to inspect. An optimistic bound may prove that even ideal resources are insufficient, but it must not displace the available-measures case: a resource starting next year contributes zero this year. Keep rate, duration, route and permission limits attached to the corresponding measure.

For stateful cases, retain the same case IDs through baseline, local prototype and integrated replay. Record the configuration, changed inputs, expected and observed boundary result, unchanged failures and state governing the recommendation. A changed pass flag is not a repair demonstration; preserved model identity does not prove provider identity. A repair attributed to resequencing preserves activity duration, resource demand and completion criteria unless a separate, supported intervention changes them; record and explain that intervention rather than silently shortening the work. Proposed replay instructions are legitimate procedure, but cannot be counted as validation evidence.

Take a picture inventory with the evidence, not after the layout. List every subject a reader would recognise on sight - a film and its poster, a product, a brand, a place, a person, a site - and give each a source:

- an asset already cleared, used with its recorded credit;
- one only the author can supply, such as a poster, a product shot or a logo: ask for it, and record the use they are entitled to make of it as its `credit`;
- none, because the subject has nothing to look at.

Plan the pictures still to come as `{ alt }`; the build lays them out and `UNSOURCED_PICTURE` holds delivery until they are filled. "The images are copyrighted" is a reason to ask, not a reason to leave the subject unseen.

Qualitative comparison needs named, comparable choices and consequences. A visual-craft claim needs visible attributed specimens and precise observations; a cover does not prove interior craft or publisher-wide style. An operating mechanism follows an actual input/output, dependency or failure path through the steps. Generic verbs, arrows and case IDs do not supply proof.

## Planning contract

Set `workflow: "new_deck"` for new work. Retain `<id>.content.json`, `<id>.plan.json` and `<id>.deck.json` together. Use unique stable slide IDs; never join records by position. Complete-copy content records and design records cover every authored slide, including cover, dividers and appendix. Mark structural content records `role: "structural"`; they retain text checks without an analytical claim requirement. Titles/claims, order and scope must agree before composition. Revisions can retain unaffected records, but reconcile all changed dependencies.

Use `{{page:stable-id}}` for cross-references; resolve after pagination, including split-page ranges. A section map owns tracker labels/order/membership. An opening summary declares `role: "executive-summary"` (the shape preset is optional) before the first section. [Copy](copy.md#executive-summary) owns its editorial content.

## Stage one: content design

Settle evidence before naming components or layouts. For each page record `claim`, `settles`, `adds` and `highlight`:

```json
{
  "schema": "professional-slides.content/v1", "id": "capacity",
  "question": "Which queues need the first capacity review?",
  "answer": "Review the three queues containing 56 of 64 unresolved requests first.",
  "pages": [{
    "id": "queue-load", "n": 2,
    "claim": "Three queues contain 56 of 64 unresolved requests",
    "settles": {"kind": "count", "what": "Six named queues: 24, 2, 16, 16, 4, 2 unresolved requests in the same snapshot"},
    "adds": "Volume prioritizes investigation; the required resource still depends on each queue's constraint.",
    "highlight": null
  }]
}
```

`settles.kind` is `count`, `share`, `rank`, `rate`, `sequence`, `comparison`, `structure` or `qualitative`; its actual evidence, basis and audience question govern the later encoding. Choose each page's [page type](page-types.md) here, while the claim is being written, not when the page is drawn: what the page `settles` usually names it (a `rank` is a ranking, a `rate` a trend, a `structure` a mechanism or a composition, several `comparison`s of one question a panels page), and where its explanation lives follows from the evidence. The storyline critique sees the types and judges the sequence's rhythm with the argument. `adds: null` means commentary is unnecessary. `highlight` is an exact phrase for emphasis or null; it is not an instruction to infer a chart maximum.

Every insight records the `shape` of its data - `series`, `peer-set`, `mix`, `measure-pair`, `bridge`, `geography`, `schedule`, `roster`, `fact` or `qualitative` - because the shape decides which [page types](page-types.md#evidence-shapes) it can carry. A title that needs a ranking and has only two numbers is found here, as a dataset still to find.

Research a comparison on the same measures for every member. A deck that found revenue and enterprise mix for one product and weekly users for the other compared nothing: find each measure for each member, and record the ones a member does not publish - `n/a` in the table is a finding, where a substitute metric hides it.

A shape also records its breadth - `breadth: { periods, series }`, `{ members }`, `{ parts }` or `{ steps }`, or the `data` itself - and the log is refused when a chart-bearing shape is too narrow: a series under six periods (four with the peers or a benchmark beside it), a peer set under six members, a measure pair under eight. Strong decks' chart pages plot about 22 values; a deck researched to the subject and one comparator plots five. Widen the dataset here - the longer window, the peers' series, the whole set - while it is still research, not when a page is refused for plotting too little.

### Complete visible copy and reference text gate

A deck authored as [page types](page-types.md#the-pages-file-is-the-dot-dash) does not write this file by hand: `author-deck.mjs` derives the content plan - claims, `settles`, `adds`, the complete text plan and each page's reading task - from the pages file and its composition, and runs these gates on it in the same pass. What follows is the contract that derived file meets.

The dot-dash is the full writing draft, not a promise to write later. Set `textContract: "complete"` on the content file. For **every page**, add `textPlan: [{id, role, text}]`, with unique block IDs, final wording and roles `title`, `body`, `exhibit`, `qualification`, `source` or `furniture`. List all headings, developed explanation, table cells, chart categories/legends/formatted values/units, annotations, notes and sources. Include recurring shell text as furniture and plan page-number formatting explicitly (for example, `02`); `{{page:stable-id}}` references resolve at composition. Furniture is excluded from density scores, but its wording must survive the same composition and export checks. Plan copy from the evidence and authoring inputs before rendering; never scrape the finished slide to create a retrospectively passing plan.

Each page also carries `textReference: {task}`: the reading task it performs. The task's word targets ship with the skill as numbers in `runtime/reading-tasks.json` (lower quartile, median, upper quartile); the page is held to them. Body counts include exhibit labels and qualifications; title, footer and any line opening with Source or Note are counted separately.

Name the reading task by the page's structure, because structure sets the floor, and the composed page is checked against it: a page with a commentary column cannot claim an exhibit-led task.

| Task | The page | Target body words, median |
| --- | --- | --- |
| `chart-led` | A chart with at most a line of takeaway | 55 |
| `chart-with-commentary` | A chart with developed points beside or below | 150 |
| `table-led` / `table-with-commentary` | A table, without or with a commentary column | 167 / 220 |
| `diagram-led` / `diagram-with-commentary` | A diagram, without or with a commentary column | 126 / 113 |
| `text-page` | Prose or points with no exhibit | 136 |
| `mixed` | Two or more exhibit families on one page | 127 |

The build checks the declared task against the composed page (`TEXT_TASK_MISMATCH`): a page with a commentary column cannot claim a task without one, or the reverse. It refuses a takeaway band that sets past three lines (`TAKEAWAY_LONG`).

The dot-dash gate reports each page's body and total words, matched-reference median and lower quartile, and `textCoverageScore = 100 × planned body words / reference median body words`. This is a relative text-coverage index, **not a taste rating**.

- **Below the floor.** The matched lower quartile is a hard floor (`TEXT_COVERAGE_LOW`): develop the missing reasoning or move the page to the task it actually performs; no rationale releases it.
- **Above the floor.** The build's density profile compares each rendered page and the whole deck with the targets (words for the task, blocks per page, words per block, longest block), and the review's density pass judges every page it flags, so a page padded to clear the floor fails there instead.
- **Neither is a quota.** Do not pad or let repeated labels substitute for explanation. Dense reference tables still need a separate check of substantive prose under [Copy](copy.md#body-copy).

The dot-dash CLI and new-deck builds require this contract by default. `--legacy` is only for explicitly auditing historical partial plans; it reports text coverage as unverified and cannot make a new-deck build pass. Revisions carrying the complete contract retain it. Keep the same wording and reference comparison through the layout plan, authored spec, composed scene, saved PPTX and rendered PDF. Deliberate copy changes update the dot-dash first and rerun the same checks. If composition splits a page, reconcile each resulting physical page into its own text plan and reference comparison; a combined parent-page score cannot certify two thinner output pages. `text-coverage.json` reports composition retention; `rendered-text-coverage.json` checks planned fragments in saved PDF text with the same reference scores. PPTX readback checks the saved text independently. Visual review still checks clipping, reading order and missing explanation; successful extraction is not visible readability.

Present the dot-dash as developed page blocks so the proof and consequence remain readable. Run `node runtime/gates/content_gates.mjs <id>.content.json`. Passing checks do not replace the title-only argument, countercase and merger review.

## Stage two: layout planning

Read the complete content record. Use [Design](design.md) and the [reference atlas](reference-atlas.md) to choose an evidence relationship before a component. For a difficult page sketch materially different candidate structures and select the one that makes the comparison easiest. This is an internal design choice, not another user approval step.

Use existing plan fields to record the exact target or deliberate absence of focus, category axis, useful anchors, heading ownership and distinct insight. Classify every component in a composite, not only the dominant exhibit. An overall `categories` treatment is insufficient when one sibling is a plain record table. [Composition](composition.md) owns allocation and peer anchors.

### The plan file the gates read

```json
{
  "schema": "professional-slides.plan/v1",
  "noPictures": "The evidence is a queue roster; photographs would not identify its bottleneck",
  "pages": [{
    "id": "queue-load", "n": 2,
    "title": "Three queues contain 56 of 64 unresolved requests",
    "exhibit": "chart.bar", "variant": "neutral",
    "why": "Compare all six counts; annotate the named three-queue set and its total, preserving the other counts. A second plot adds no proof.",
    "architecture": "exhibit-full", "anchors": false,
    "highlight": null, "annotation": "named set and total", "insight": "none", "items": 6
  }]
}
```

| Field | Meaning |
| --- | --- |
| `id`, `title` | Stable slide ID and exact approved title |
| `n`, `kind` | Reporting position; structural type where applicable |
| `exhibit`, `variant` | Selected encoding and treatment; implementation controls belong in deck props |
| `why` | Evidence relationship, shared key/scale, hierarchy, treatment rationale and merger decision |
| `kind` | Mark a cover as `cover`; analytical pages, including appendix evidence, use `content` or omit this field |
| `architecture` | Explicit normalized structure; `auto` is not a considered design |
| `anchors` | Authored supported icons/images, or false when unnecessary |
| `highlight` | Exact phrase or null; chart/table focus is selected by exact keys in deck props |
| `treatment`, `annotation` | Intended visual choices, identifying affected children in `why` |
| `insight` | `filled`, `outline` or `none`; actual distinct sentence belongs in content/deck |
| `rows`, `items` | Actual evidence size for capacity planning |
| `series` | Deliberately comparable repeated task, with rationale; not a repetition exemption by label alone |

Run `node runtime/gates/plan_gates.mjs <id>.plan.json`. The build runs available sidecars automatically. Mix, icon, treatment and density statistics are advisory, never decoration quotas. Review [normalized relationships](design.md#page-architecture-and-repetition) across the actual sequence as well as the planned labels.

## Approve it

For new work or changes outside authorized structure, present the dot-dash and obtain confirmation before slide authoring. Record which version is authorized. A standing instruction to proceed satisfies this within its scope. A requested change directly authorizes that change and its necessary dependencies; do not ask again merely because the artifact version changed.

For an existing deck, inventory exact current titles and evidence first. Preserve unaffected structure. Perform internal handoff reviews without inventing new approval gates.

## Worked example: a capacity decision

This synthetic example demonstrates the reasoning; it is not a claim about a real operation. The question is whether a four-week workload reduction permits a vendor commitment to be cut. The hypothetical source record defines 120 released hours, 80 that fit the vendor's shifts, 60 that the contract permits cancelling, a 50-hour minimum cancellation and £30 per cancelled hour. All five are explicit scenario inputs.

**Proof outline.**

| Stable ID | Exact title | Proof and distinct contribution |
| --- | --- | --- |
| answer | Cancel 60 vendor hours only if the shift and contract conditions hold | Opening summary: conditional answer, feasible quantity, cash effect and authorization required. Developed bullet rows suffice. |
| feasible | Shift and contract limits reduce 120 released hours to 60 cancellable hours | One joined exhibit keeps released, schedulable and cancellable quantities distinct. The 60-hour feasible reduction exceeds the 50-hour contract minimum and yields £1,800 in this illustration. |
| reversal | A 45-hour scheduling limit would eliminate the cancellation | A countercase changes one named input: min(45, 60) falls below the 50-hour minimum. Cash saving is then zero under the stated contract, not £1,350. |
| decision | Verify shifts and cancellation terms before changing the commitment | Close: owner, missing real evidence and conditional action. The synthetic calculation does not authorize a real contract change. |

**Merger challenge.** Separate pages for released hours, schedulable hours and cancellable hours would force a mental join. Consolidate them into `feasible`. Keep `reversal` only if the reader needs the countercase developed; otherwise put it beside the base case on a common schema. A four-page worked example is a diagnostic, not a qualifying 50-page skill evaluation.

**Design selection.** A shared-row reconciliation can attach the scheduling and contract constraints to their quantities. An unrelated process diagram and three commentary columns would not make the feasible result clearer. These rows are successive states of one quantity, not unordered category classes. Use ordinary chart series colors, place the 50-hour threshold at the point of decision, and highlight only the decisive authored result. A short favorable/adverse verdict may use status text color; the marks do not.

**Handoff.** Carry the same stable IDs, quantities, conditions and evidence status into content, plan and deck records. Recalculate summary, exhibit and close when the scheduling input changes. Inspect the saved slide to confirm that the threshold and distinct quantity labels remain legible and attached to the calculation they qualify.
