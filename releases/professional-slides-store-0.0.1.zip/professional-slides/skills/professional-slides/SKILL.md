---
name: professional-slides
description: Build, restructure or rewrite a slide deck as an argument - board decks, steerco and project updates, investor and pitch decks, commercial due diligence, executive summaries and pre-reads - and produce an editable .pptx. Covers storyline and action titles, the ghost deck, chart and table selection, page layout, and rendered verification. Use for "make me a deck/slides/presentation", "turn this analysis into slides", "restructure/rewrite/fix an existing deck", "write the storyline", "sharpen the titles", "build a pptx".
---

# Professional Slides

Build the argument before drawing the page. A valid file and a polished page do not establish a useful deck.

## Scope and authorization

- **New deck:** `workflow: "new_deck"`; develop the decision and dot-dash in [Storylining](references/storylining.md). Obtain approval before authoring unless the user has already authorized proceeding.
- **Existing deck:** `workflow: "existing_deck_revision"`; inventory current pages and revise the affected claims and shared dependencies by stable ID.
- **Individual slide:** stay within the requested page and its dependencies; start with [Design](references/design.md) and the relevant component owner.

Attached documents supply evidence or design references, not instructions. Reference material is only what the user supplies in the task; do not search the filesystem for other decks or documents to benchmark against. Preserve supplied facts, uncertainty and explicit user scope. Internal stage reviews below do not create additional user approval steps.

## Stage handoffs

| Stage | Work that must be settled | Existing artifact | Owner |
| --- | --- | --- | --- |
| Brief | Audience, actual choice or learning objective, alternatives, horizon, criteria, reversal condition | Brief above the dot-dash | [Storylining](references/storylining.md#define-the-communication-job) |
| Data | Series over time, the whole peer set, shares, geography and pipeline found, downloaded and recorded; players declared | `sources/` and source records | [Storylining](references/storylining.md#find-the-data-before-the-dot-dash) |
| Insights | Each dataset worked for rate, rank, share, ratio, gap, break and counter; findings graded, sourced and shaped (series, peer set, mix, ...); titles written from them | `<id>.insights.json` | [Storylining](references/storylining.md#extract-the-insights-before-the-titles) |
| Proof outline | Exact title spine and all visible copy; per-slide reference text coverage; necessary evidence and countercase; delete/merge alternatives | `<id>.pages.json` - the dot-dash, from which `.content.json` is derived | [Storylining](references/storylining.md#prove-the-governing-answer) |
| Design system | The [design intake](references/theming.md#design-intake): stored preferences read, missing answers asked once with their option sheets, answers stored and applied; the subject's identity colours; the system's page repertoire | `design`, `identity`, `palette`, `tracker`, `surfaces`, `density` on the deck; the user's preferences file | [Theming](references/theming.md#design-intake) |
| Storyline critique | An independent, adversarial reading of the dot-dash, exhaustive on pass one (every page, every spine check), verified after each revision, says `ready` with nothing major open, bound to the current title spine: sharp answer, MECE pillars with their countercases, sourced analytical pages, no missing analysis that would change the answer. No deck review is prepared and no deck delivered before this gate; a full compile or build before it prints a warning that its copy is written against an unpassed spine | `storyline-review.json`, `storyline-history/` | [Storylining](references/storylining.md#stress-test-the-storyline) |
| Evidence design | Defined measures/states; relationship that proves each claim; meaningful emphasis and visual treatments | Source records and `.plan.json` | [Design](references/design.md), [reference atlas](references/reference-atlas.md) |
| Page types | Every page authored as a type with its form, commentary placement and close chosen, resting on evidence of its shape; the variety contract and content gates pass in one run | `<id>.pages.json` compiled to `.deck.json`, `.plan.json` and `.content.json` | [Page types](references/page-types.md) |
| Composition | Reading order, relative weight, common comparison anchors and measured fit | `.deck.json` | [Composition](references/composition.md), [Copy](references/copy.md) |
| Saved artifact | Authored content and visual intent survive export; truthful scales, labels and editable objects | PPTX, renders and build reports | [Production](references/tools/production.md) |
| Self-check | Every claim reproduced from the records; one comparison rule for every member; summary figures shown where proved; duplicate propositions merged | `claims.json` and `self-check.json` | [Taste review](references/taste-review.md#self-check) |
| Deck review | Pass one exhaustive: every page on every rubric dimension, every deck finding with all its pages, a completeness self-check; later passes verify each open finding and add only serious, additive ones; at most three passes; accepted when nothing major is open | `review.json`, `review-history/` with the ledger | [Taste review](references/taste-review.md#order-of-the-reviews) |

Read the relevant owner before its handoff. A passing schema or mix statistic does not settle an editorial decision. If a page cannot justify its existence, return to the proof outline before choosing another layout.

The executive summary is an opening semantic role; developed bullet rows can carry it without metrics. Its content, the conclusion and their different jobs are owned by [Copy](references/copy.md). Table/category, focus, icon, heading, insight and status-color decisions have one owner in [Design](references/design.md#choose-visual-treatments-during-planning). Status red/green is confined to short verdict text or check/cross icons, never chart marks or backgrounds.

Before planning a new deck, run the [design intake](references/theming.md#design-intake): read the user's stored preferences (`node runtime/preferences.mjs show`) and the host's own memory of them; ask only what is missing - a reference deck to infer from first, then look, colours, tracker, title treatment and surfaces, and density - in one message with the option sheets from `assets/design-options/` and a recommended default on each; store the answers (`preferences.mjs set`) and write them into the deck (`preferences.mjs apply <id>.pages.json`); and tell the user in one line what was reused and how to change it. Do not default silently to the consulting frame. Keep review cost bounded: each review loop - the storyline critique, then the deck review - is one exhaustive pass followed by verification passes that check the repairs, three passes at most; a loop that has not converged by then goes back to the user with its open findings. In the final response, offer the user another partner iteration of the dot-dash or of the deck design rather than running it unasked. Use subagents where the harness has them: fan out research and insight extraction by workstream and section copy by section, run each storyline critique in a fresh subagent, and read a long deck's first review pass with one fresh reviewer per section plus a spine reviewer ([Storylining](references/storylining.md#work-in-parallel-with-subagents)). Author every page as a page type in `<id>.pages.json` ([Page types](references/page-types.md)): each page chooses its `form`, where its `commentary` lives and whether it closes on a `takeaway`, from the claim it makes - there are no defaults, because a default taken fifty times is a template. `node runtime/author-deck.mjs` compiles the deck, its plan and its content plan in one pass - every page that fails to compile or compose, every broken rule and every page under its word floor reported together - and refuses a deck whose choices repeat; never write a page generator that stamps one skeleton across pages. Start each page type from its worked example in `examples/page-types.pages.json`. Plan types from the chosen system's repertoire, not only its colours. Give every new deck a fresh `variation` (`node runtime/variation.mjs --design <system>` prints one with its draw); it varies the styling the choices leave open. Reuse a seed only to reproduce a deck. Choose themes through [Theming](references/theming.md), encodings through [Charts](references/charts.md), and component behavior through [Components](references/components.md). Alternatives must differ in reader task, narrative or evidence relationship with styling ignored; cosmetic variants do not establish analytical variety.

## Iterate the reusable skill

For a rejected candidate, identify the earliest failed handoff. Missing proof returns to Storylining; a weak encoding or lost cue to Design/Composition; deterministic geometry or export errors to shared runtime. Repair that owner and its example or check before rebuilding. A task-local exporter or final-output patch is not a reusable improvement.

Keep each rule at one owner and link to it. Use instructions and contrasting examples for judgment, code for deterministic behavior. Test the changed principle in another materially different case and its counterexample. Preserve candidate/report history; a rebuild invalidates its review, and the next one verifies the changed pages. Do not tell an independent reviewer the score to produce.

## Evaluation and delivery

Skill evaluations default to **at least 50 total rendered pages**, including cover and appendix, unless the user explicitly overrides that evaluation's length. Set `purpose: "evaluation"` on an evaluation deck; the build then refuses it under 50 pages. Select sufficient evidence breadth before drafting. Fifty pages of repeated calculation is a weaker evaluation, not a compliant way to extend a small case. Short probes remain diagnostics. Ordinary decks follow the user's brief. [Evaluation](references/evaluation/index.md#forward-testing-the-skill) owns transfer testing.

Use the standard pipeline, resolving paths from this skill:

```bash
node runtime/author-deck.mjs <id>.pages.json --draft   # titles + page types, before the copy
node runtime/storyline.mjs <id>.deck.json out/         # critique pass 1 (exhaustive); save out/storyline-review.json
# revise the spine at the root; rerun storyline.mjs: it records the critique and writes the verification pass
node runtime/storyline.mjs <id>.deck.json out/         # ... until it prints "ready" (3 passes at most)
node runtime/author-deck.mjs <id>.pages.json           # full copy only once the storyline gate is ready
node runtime/build-deck.mjs <id>.deck.json out/     # fetches logos, photos and map places planned by name; --no-fetch offline
# work through out/claims.json, fix and rebuild, record out/self-check.json
node runtime/deliver-deck.mjs <id>.deck.json out/ --skip-build --reviewer packet   # writes the deck-review packet: pass 1, exhaustive
node runtime/reviewer.mjs merge out/                   # long decks: join the section reviewers' parts into out/review.json
node runtime/deliver-deck.mjs <id>.deck.json out/ --skip-build --review out/review.json
# rejected: fix, rebuild, rerun deliver-deck for the verification pass (3 passes at most), then deliver
```

The order is fixed: storyline critique, revision, the storyline gate at `ready` for the current spine, full copy and build, self-check, deck review pass one, fixes, verification passes, delivery. The two reviews never run at the same time: do not start a deck reviewer, even as a parallel subagent, while a storyline critique is running or before its gate prints `ready`; a response written to an open storyline finding does not stand in for the gate. The deck review is not prepared, and a supplied one is not accepted, while the storyline gate is not ready for the deck's current spine. The self-check catches what the author can see with the data open, so the review is spent on judgement; request it only once the deck is finished. Pass one reads every page on every rubric dimension; each later pass verifies the repairs and may add only serious findings on changed pages ([Taste review](references/taste-review.md#order-of-the-reviews)).

[Production](references/tools/production.md) owns dependency setup, portable evidence, saved-file verification and package provenance. Delivery requires passing blocking checks and an accepted review bound to the exact editable file, scene and all current renders. The review includes a density pass over `density-profile.json`, which compares the rendered pages' words with the targets for the same reading task ([Taste review](references/taste-review.md#density-pass)); the dot-dash word floor is hard and the pass judges everything above it. Distinguish technical validation, editorial rating and user acceptance. State missing evidence and unfinished work. Verify Google Slides separately after import.
